"""Command line interface."""

import argparse
from pathlib import Path
from .core import StoryState
from .prompts import compile_prompt
from .autonomous import WritersRoom
from .adapters import EchoAdapter, optional_openai_adapter


def main(argv=None):
    p = argparse.ArgumentParser(prog="muse", description="Muse Autonomous Writers' Room")
    p.add_argument("--dir", default="./muse_project")
    sub = p.add_subparsers(dest="cmd", required=True)

    x = sub.add_parser("init")
    x.add_argument("--title", default="Working Title")
    x.add_argument("--premise", default="")
    x.add_argument("--genre", default="horror")
    x.add_argument("--format", default="novel")
    x.add_argument("--voice", default="cinematic")
    x.add_argument("--audience", default="adult commercial")

    x = sub.add_parser("prompt")
    x.add_argument("agent")
    x.add_argument("task")
    x.add_argument("--context", default="")

    x = sub.add_parser("run")
    x.add_argument("--passes", type=int, default=3)
    x.add_argument("--model", choices=["offline", "openai"], default="offline")

    x = sub.add_parser("set-stage")
    x.add_argument("stage", choices=["concept", "outline", "draft", "revision", "package"])

    x = sub.add_parser("status")

    args = p.parse_args(argv)
    project = Path(args.dir)
    state = StoryState.load(project)

    if args.cmd == "init":
        state = StoryState(title=args.title, premise=args.premise, genre=args.genre,
                           format=args.format, voice=args.voice, audience=args.audience)
        state.save(project)
        print(f"Initialized {project}: {state.title}")
        return 0

    if args.cmd == "status":
        print(f"{state.title}\nGenre: {state.genre}\nFormat: {state.format}\nStage: {state.stage}\n"
              f"Version: {state.version}\nOutputs: {len(state.outputs)}")
        return 0

    if args.cmd == "set-stage":
        state.stage = args.stage
        state.save(project)
        print(f"Stage set to {args.stage}")
        return 0

    if args.cmd == "prompt":
        print(compile_prompt(state, args.agent, args.task, args.context))
        state.save(project)
        return 0

    if args.cmd == "run":
        if args.model == "openai":
            cls = optional_openai_adapter()
            if cls is None:
                raise SystemExit("OpenAI adapter unavailable. Install the optional SDK or use --model offline.")
            adapter = cls()
        else:
            adapter = EchoAdapter()
        room = WritersRoom(state, adapter)
        results = room.run(args.passes)
        room.save_outputs(project)
        for r in results:
            print(f"\n=== {r['agent'].upper()} PASS ===\n{r['output']}\n")
        return 0

    return 1
