"""Genre, format, and craft profiles for Muse."""

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class GenreProfile:
    name: str
    promise: str
    engines: List[str]
    scene_priorities: List[str]
    avoid: List[str]
    beats: List[str]


GENRES: Dict[str, GenreProfile] = {
    "horror": GenreProfile("Commercial Horror",
        "dread, escalation, consequence, and emotionally specific terror",
        ["dread", "threat", "reversal", "psychological_pressure"],
        ["sensory unease", "withheld information", "character vulnerability"],
        ["gratuitous exposition", "repetitive scares", "empty shock"],
        ["normality", "disturbance", "denial", "escalation", "revelation", "confrontation", "aftermath"]),
    "romance": GenreProfile("Commercial Romance",
        "emotional intimacy, desire, conflict, vulnerability, and earned connection",
        ["chemistry", "misbelief", "yearning", "relationship_turn"],
        ["instant intimacy", "conflict without stakes", "unearned reconciliation"],
        ["meeting", "spark", "resistance", "deepening", "rupture", "choice", "commitment"]),
    "comedy": GenreProfile("Comedy",
        "character-driven comic pressure, reversals, escalation, and release",
        ["comic_timing", "status", "misunderstanding", "escalation"],
        ["jokes without character", "same beat repeated", "punching down"],
        ["setup", "complication", "misread", "escalation", "collapse", "reversal", "button"]),
    "cult": GenreProfile("Cult / Midnight",
        "distinctive voice, transgressive premise, quotable moments, and controlled weirdness",
        ["iconography", "absurdity", "subculture", "surprise"],
        ["randomness without pattern", "edginess without purpose", "derivative nostalgia"],
        ["hook", "ritual", "rule", "violation", "revelation", "chaos", "mythic button"]),
    "thriller": GenreProfile("Thriller",
        "urgency, jeopardy, reversals, information control, and propulsion",
        ["tension", "clock", "reversal", "information_gap"],
        ["coincidence as solution", "passive protagonist", "dead middle"],
        ["threat", "pursuit", "complication", "reversal", "trap", "countermove", "payoff"]),
    "mystery": GenreProfile("Mystery",
        "fair-play clues, uncertainty, investigation, and a satisfying reveal",
        ["clues", "suspects", "misdirection", "reveal"],
        ["withholding unfairly", "magic clues", "solution dump"],
        ["question", "clue", "false lead", "pattern", "reveal", "consequence", "explanation"]),
    "literary": GenreProfile("Literary Fiction",
        "interiority, language, ambiguity, social texture, and thematic resonance",
        ["subtext", "motif", "interiority", "image_system"],
        ["ornament without meaning", "over-explaining", "manufactured profundity"],
        ["image", "disruption", "interiority", "pressure", "recognition", "choice", "echo"]),
    "fantasy": GenreProfile("Fantasy",
        "wonder, coherent rules, consequence, character desire, and mythic scale",
        ["world_rules", "wonder", "myth", "quest"],
        ["infodumps", "convenient magic", "worldbuilding detached from character"],
        ["ordinary", "call", "threshold", "trial", "revelation", "choice", "return"]),
    "science_fiction": GenreProfile("Science Fiction",
        "speculative premise, human consequence, systems, and extrapolation",
        ["speculation", "systems", "consequence", "wonder"],
        ["technical exposition replacing drama", "magic-tech solutions", "generic future"],
        ["premise", "contact", "adaptation", "systemic pressure", "discovery", "choice", "consequence"]),
    "crime": GenreProfile("Crime",
        "motive, pressure, moral compromise, evidence, and consequence",
        ["motive", "evidence", "moral_pressure", "reversal"],
        ["procedural wallpaper", "villain monologues", "consequence-free crime"],
        ["crime", "investigation", "compromise", "pressure", "betrayal", "reckoning", "aftermath"]),
    "satire": GenreProfile("Satire",
        "comic contradiction, institutional pressure, status games, and target clarity",
        ["irony", "status", "hypocrisy", "escalation"],
        ["confusing target with victim", "lecture disguised as joke", "one-note caricature"],
        ["premise", "contradiction", "status", "escalation", "exposure", "collapse", "button"]),
}

FORMATS = {
    "novel": {"name": "Novel", "units": "chapters", "target": "sustained prose"},
    "short_story": {"name": "Short Story", "units": "scenes", "target": "compressed narrative"},
    "feature": {"name": "Feature Screenplay", "units": "sequences", "target": "visual screenplay"},
    "network_tv": {"name": "Network Television", "units": "acts", "target": "broadcast-ready episodic script"},
    "sitcom": {"name": "Sitcom", "units": "beats", "target": "ensemble comedy with act turns"},
    "youtube_sketch": {"name": "YouTube Sketch", "units": "beats", "target": "fast visual/digital comedy"},
    "pilot": {"name": "TV Pilot", "units": "acts", "target": "series engine plus pilot story"},
    "stage_play": {"name": "Stage Play", "units": "scenes", "target": "performable dialogue and blocking"},
    "audio_drama": {"name": "Audio Drama", "units": "scenes", "target": "sound-driven storytelling"},
}

VOICE_MODES = {
    "cinematic": "visual, concrete, economical, image-led",
    "intimate": "close interiority, emotional specificity, selective detail",
    "lyrical": "rhythmic language, recurring imagery, controlled metaphor",
    "visceral": "physical sensation, consequence, embodied perception",
    "noir": "compressed observation, moral ambiguity, hard-edged dialogue",
    "comic": "timing, reversal, status shifts, precision, surprise",
    "romantic": "sensory attraction, vulnerability, subtext, emotional reciprocity",
    "uncanny": "ordinary detail made subtly wrong, ambiguity, delayed recognition",
    "procedural": "clear causality, evidence, process, disciplined exposition",
    "minimalist": "short sentences, implication, omission, high signal-to-noise",
    "epic": "scale, mythic imagery, long consequence, dramatic contrast",
}

def get_genre(name: str) -> GenreProfile:
    key = name.lower().replace("-", "_").replace(" ", "_")
    if key not in GENRES:
        raise KeyError(f"Unknown genre: {name}. Available: {', '.join(sorted(GENRES))}")
    return GENRES[key]
