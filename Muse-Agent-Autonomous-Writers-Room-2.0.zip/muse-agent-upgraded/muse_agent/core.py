"""Core project state and deterministic craft analysis."""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any
import json
import re


@dataclass
class StoryState:
    title: str = "Working Title"
    premise: str = ""
    genre: str = "horror"
    format: str = "novel"
    voice: str = "cinematic"
    audience: str = "adult commercial"
    stage: str = "concept"
    version: int = 1
    decisions: List[str] = field(default_factory=list)
    scenes: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    prompt_history: List[Dict[str, Any]] = field(default_factory=list)
    outputs: List[Dict[str, Any]] = field(default_factory=list)

    @classmethod
    def load(cls, project: Path) -> "StoryState":
        p = project / "story.json"
        if not p.exists():
            return cls()
        return cls(**json.loads(p.read_text(encoding="utf-8")))

    def save(self, project: Path) -> None:
        project.mkdir(parents=True, exist_ok=True)
        (project / "story.json").write_text(
            json.dumps(asdict(self), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def record_prompt(state: StoryState, agent: str, prompt: str) -> None:
    state.prompt_history.append({"time": timestamp(), "agent": agent, "prompt": prompt})


def extract_signals(text: str) -> Dict[str, List[str]]:
    lower = text.lower()
    vocab = {
        "emotion": ["fear", "feared", "fearful", "love", "loved", "loving", "grief", "grieving", "rage", "angry", "shame", "ashamed", "hope", "hopeful", "desire", "desired", "jealousy", "jealous", "wonder", "wondered"],
        "stakes": ["death", "money", "family", "career", "freedom", "secret", "reputation", "survival"],
        "image": ["door", "mirror", "water", "fire", "blood", "clock", "house", "road", "window", "phone"],
        "comic": ["awkward", "embarrassing", "lie", "mistake", "misunderstanding", "ridiculous", "secret"],
    }
    result = {}
    for k, words in vocab.items():
        canonical = []
        for w in words:
            if re.search(rf"\b{re.escape(w)}\b", lower):
                base = w
                if w.startswith("fear"): base = "fear"
                elif w.startswith("love"): base = "love"
                elif w.startswith("griev"): base = "grief"
                elif w.startswith("angry"): base = "rage"
                elif w.startswith("ashamed"): base = "shame"
                elif w.startswith("hope"): base = "hope"
                elif w.startswith("desired"): base = "desire"
                elif w.startswith("jealous"): base = "jealousy"
                elif w.startswith("wonder"): base = "wonder"
                if base not in canonical:
                    canonical.append(base)
        result[k] = canonical
    return result


def scene_diagnostics(scene: Dict[str, Any]) -> List[str]:
    """Simple deterministic gate; an LLM/editor may enrich it later."""
    text = str(scene.get("text", ""))
    diagnostics = []
    if len(text.split()) < 80:
        diagnostics.append("SCENE_TOO_SHORT: verify the scene has enough dramatic development.")
    if not scene.get("goal"):
        diagnostics.append("MISSING_GOAL: identify what the viewpoint character wants in this scene.")
    if not scene.get("obstacle"):
        diagnostics.append("MISSING_OBSTACLE: create resistance rather than passive exposition.")
    if not scene.get("turn"):
        diagnostics.append("MISSING_TURN: define what changes by the end of the scene.")
    if text.count("very ") > 3:
        diagnostics.append("ADVERB_CLUSTER: inspect repeated 'very' constructions.")
    if "suddenly" in text.lower():
        diagnostics.append("SUDDENLY_CHECK: make the causal trigger visible instead of using a shortcut.")
    return diagnostics
