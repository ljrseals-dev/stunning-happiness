"""Prompt compiler: autonomous, structured, model-agnostic."""

from .profiles import get_genre, FORMATS, VOICE_MODES
from .core import StoryState, record_prompt


SYSTEM_CORE = """You are MUSE, an autonomous professional writers' room.
Your job is to develop original, commercially viable creative material while
protecting continuity, character causality, voice consistency, and audience
expectations.

Do not imitate a living author or reproduce a recognizable author's signature
voice. Instead, use high-level craft attributes such as dread, intimacy,
comic timing, lyrical imagery, suspense, sparse prose, or noir compression.

You are not a single writer. You coordinate specialist passes:
ARCHITECT -> CHARACTER -> SCENE -> DIALOGUE -> GENRE -> CONTINUITY ->
EDITOR -> MARKET/PACKAGING.

Never pretend that market success, bestseller status, agent interest, or
publication is guaranteed. Produce the strongest manuscript/package the
evidence and brief support, then identify remaining weaknesses.
"""


AGENTS = {
    "architect": "Build premise, stakes, story engine, structure, reversals, and ending logic.",
    "character": "Build wants, needs, wounds, contradictions, relationships, voice, and transformation.",
    "scene": "Convert beats into playable scenes with objective, obstacle, tactics, escalation, and turn.",
    "dialogue": "Write character-specific dialogue with subtext, rhythm, interruption, silence, and status.",
    "genre": "Check genre promise, escalation, conventions, novelty, and reader expectation.",
    "continuity": "Track facts, chronology, objects, relationships, clues, injuries, geography, and causality.",
    "editor": "Diagnose pacing, redundancy, exposition, weak verbs, tonal drift, false stakes, and endings.",
    "packager": "Create logline, synopsis, pitch, query components, episode descriptions, title options, and submission-ready metadata.",
    "comedy": "Optimize setup, expectation, escalation, reversal, status, specificity, and the final button.",
    "tv": "Think in acts, teasers, act-outs, commercial turns, episodic engine, and recurring ensemble dynamics.",
}


def compile_prompt(state: StoryState, agent: str, task: str, context: str = "") -> str:
    if agent not in AGENTS:
        raise KeyError(f"Unknown agent: {agent}")
    genre = get_genre(state.genre)
    fmt = FORMATS[state.format]
    voice = VOICE_MODES.get(state.voice, state.voice)
    prompt = f"""{SYSTEM_CORE}

ROLE: {agent.upper()}
{AGENTS[agent]}

PROJECT
Title: {state.title}
Premise: {state.premise or "[not established]"}
Genre: {genre.name}
Genre promise: {genre.promise}
Format: {fmt['name']} ({fmt['target']})
Audience: {state.audience}
Voice attributes: {voice}
Current stage: {state.stage}

GENRE ENGINES
{", ".join(genre.engines)}

FORMAT BEATS
{", ".join(genre.beats)}

TASK
{task}

CONTEXT
{context or "[none]"}

OUTPUT CONTRACT
1. Return original material, not commentary about how to write it, unless the task asks for analysis.
2. Preserve established facts unless explicitly revising them.
3. Make every major choice causal: character choice -> consequence -> new pressure.
4. Prefer specific images, behavior, and subtext over generic adjectives.
5. If a requested element is weak, repair it rather than merely praising it.
6. End with a compact QUALITY_GATE listing the strongest element and the next weakness to fix.
"""
    record_prompt(state, agent, prompt)
    return prompt


def autonomous_prompt_sequence(state: StoryState) -> list[str]:
    """Returns the default writers' room sequence for unattended runs."""
    if state.stage == "concept":
        return [
            compile_prompt(state, "architect", "Develop 3 distinct premises from the brief; select no winner automatically. State the tradeoffs."),
            compile_prompt(state, "character", "Build the protagonist, antagonist/opposing force, primary relationship, and central contradiction."),
            compile_prompt(state, "genre", "Stress-test the premise against genre expectations and identify five opportunities for originality."),
        ]
    if state.stage == "outline":
        return [
            compile_prompt(state, "architect", "Create the full beat map, including reversals and a causally earned ending."),
            compile_prompt(state, "character", "Track character transformation through every major beat."),
            compile_prompt(state, "continuity", "Create a continuity ledger of facts, clues, timeline, locations, and unresolved threads."),
        ]
    if state.stage == "draft":
        return [
            compile_prompt(state, "scene", "Draft the next scene from the approved beat. Make the scene turn unavoidable in retrospect."),
            compile_prompt(state, "dialogue", "Rewrite dialogue for distinct character voices and subtext."),
            compile_prompt(state, "genre", "Run a genre-pressure pass and repair weak escalation."),
        ]
    if state.stage == "revision":
        return [
            compile_prompt(state, "editor", "Perform a hard developmental edit. Identify structural and scene-level failures, then propose repairs."),
            compile_prompt(state, "continuity", "Run a contradiction and unresolved-thread audit."),
            compile_prompt(state, "genre", "Run a genre and audience expectation audit without flattening originality."),
        ]
    return [
        compile_prompt(state, "packager", "Prepare logline, short pitch, synopsis, and format-specific presentation material."),
        compile_prompt(state, "editor", "Run a final quality gate for clarity, originality, pacing, and consistency."),
    ]
