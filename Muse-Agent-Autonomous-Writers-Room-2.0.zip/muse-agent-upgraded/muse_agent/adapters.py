"""Optional model adapters. The package works without a neural model."""

from typing import Protocol


class ModelAdapter(Protocol):
    def generate(self, prompt: str) -> str: ...


class EchoAdapter:
    """Safe offline adapter for testing orchestration and prompt generation."""
    def generate(self, prompt: str) -> str:
        return "[OFFLINE MODEL]\n\n" + prompt


class CallableAdapter:
    """Wrap any user-supplied callable(prompt)->str."""
    def __init__(self, fn):
        self.fn = fn
    def generate(self, prompt: str) -> str:
        return self.fn(prompt)


def optional_openai_adapter():
    """Return a lazy adapter if an OpenAI-compatible SDK is installed.

    Configuration is intentionally external; no key is stored by Muse.
    """
    try:
        from openai import OpenAI
    except ImportError:
        return None

    class Adapter:
        def __init__(self, model="gpt-5.6"):
            self.client = OpenAI()
            self.model = model
        def generate(self, prompt):
            r = self.client.responses.create(model=self.model, input=prompt)
            return r.output_text
    return Adapter
