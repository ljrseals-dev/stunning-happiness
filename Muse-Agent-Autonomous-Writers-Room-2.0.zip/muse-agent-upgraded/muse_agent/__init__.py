"""Muse Autonomous Writers' Room."""

__version__ = "2.0.0"
