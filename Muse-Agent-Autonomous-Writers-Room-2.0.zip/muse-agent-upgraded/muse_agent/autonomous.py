"""Autonomous writers' room orchestration."""

from .core import StoryState, timestamp
from .prompts import autonomous_prompt_sequence


class WritersRoom:
    """Deterministic orchestration around a pluggable generation model."""

    def __init__(self, state: StoryState, adapter):
        self.state = state
        self.adapter = adapter

    def run(self, max_passes: int = 3) -> list[dict]:
        base_prompts = autonomous_prompt_sequence(self.state)[:max_passes]
        results = []
        prior_output = ""
        for i, base_prompt in enumerate(base_prompts, 1):
            agent = self._agent_from_prompt(base_prompt)
            prompt = base_prompt
            if prior_output:
                prompt += "\n\nPREVIOUS SPECIALIST PASS\n" + prior_output
                prompt += "\n\nINSTRUCTION: Treat the previous pass as working material. Preserve useful facts, repair weaknesses, and add value rather than merely paraphrasing it."
            output = self.adapter.generate(prompt)
            record = {
                "time": timestamp(),
                "pass": i,
                "agent": agent,
                "prompt": prompt,
                "output": output,
            }
            self.state.outputs.append(record)
            results.append(record)
            prior_output = output
        self.state.version += 1
        return results

    @staticmethod
    def _agent_from_prompt(prompt: str) -> str:
        first = prompt.splitlines()
        for line in first:
            if line.startswith("ROLE:"):
                return line.split(":", 1)[1].strip().lower()
        return "unknown"

    def save_outputs(self, project) -> None:
        project.mkdir(parents=True, exist_ok=True)
        for i, item in enumerate(self.state.outputs, 1):
            path = project / f"pass_{i:03d}_{item['agent']}.md"
            path.write_text(item["output"], encoding="utf-8")
        self.state.save(project)
