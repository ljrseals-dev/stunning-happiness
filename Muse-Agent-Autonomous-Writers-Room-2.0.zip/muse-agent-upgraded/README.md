# Muse Autonomous Writers' Room 2.0

Muse started as a symbolic writing companion. This version turns it into a
model-agnostic **autonomous creative production system**.

## What changed

### 1. Genre expansion

Built-in profiles include:

- Commercial horror
- Romance
- Comedy
- Cult / midnight
- Thriller
- Mystery
- Literary fiction
- Fantasy
- Science fiction
- Crime
- Satire

The architecture is extensible: add a `GenreProfile` rather than rewriting
the engine.

### 2. Media expansion

Supported format profiles:

- Novel
- Short story
- Feature screenplay
- Network television
- Sitcom
- TV pilot
- YouTube sketch
- Stage play
- Audio drama

### 3. More writing modes

Muse separates **voice attributes** from genre. Examples:

`cinematic`, `intimate`, `lyrical`, `visceral`, `noir`, `comic`, `romantic`,
`uncanny`, `procedural`, `minimalist`, `epic`.

This deliberately describes craft attributes instead of copying a living
author's recognizable voice. For example, a request for "premium commercial
horror with psychological dread, concrete sensory detail, and restrained
prose" can be represented without asking the model to impersonate a named
author.

### 4. Autonomous writers' room

The orchestration chain is:

`ARCHITECT -> CHARACTER -> SCENE -> DIALOGUE -> GENRE -> CONTINUITY -> EDITOR -> PACKAGER`

The exact passes depend on project stage.

Stages:

`concept -> outline -> draft -> revision -> package`

The engine automatically compiles prompts with:

- project state
- genre promise
- format constraints
- voice attributes
- agent role
- current task
- output contract
- continuity context

### 5. Neural networks / LLMs

Muse does **not** require a neural model for its core operation.

It provides:

- `EchoAdapter` for deterministic offline testing
- `CallableAdapter` for any local model/service
- an optional OpenAI-compatible adapter

This is intentional. The orchestration, state machine, genre logic, quality
gates, and prompt compiler should remain deterministic while the generative
model remains replaceable.

A serious production deployment can put a local or hosted neural model behind
the same `ModelAdapter` interface.

## Example

```bash
python -m muse_agent.cli init \
  --dir ./my_story \
  --title "The House Beneath the Station" \
  --premise "A night-shift cleaner discovers a sealed platform beneath a city station." \
  --genre horror \
  --format novel \
  --voice uncanny
```

Then:

```bash
python -m muse_agent.cli set-stage --dir ./my_story outline
python -m muse_agent.cli run --dir ./my_story --passes 3
```

For a comedy YouTube project:

```bash
python -m muse_agent.cli init \
  --dir ./sketch \
  --title "Customer Service for the Apocalypse" \
  --premise "A call-center worker discovers every caller is reporting the end of the world." \
  --genre comedy \
  --format youtube_sketch \
  --voice comic
```

## Commercial-writing quality gates

The system can be extended with additional gates for query-letter compliance,
synopsis length, episode act structure, screenplay scene formatting, and
platform-specific delivery requirements. These are packaging checks, not a
claim that any agent or publisher will accept the work.

### Automated prompting

A run is sequential rather than merely parallel:

`Architect output -> Character pass -> Genre pressure -> Continuity/Edit -> Package`

Each later pass receives the prior specialist output and an instruction to
preserve facts while repairing weaknesses. This makes the loop suitable for
unattended batch generation when paired with an external scheduler/queue.


Muse does not claim "New York Times bestseller" status. Instead it creates
measurable gates around the craft and packaging problems that matter:

- premise clarity
- character desire
- causal escalation
- scene objective
- obstacle
- turn
- dialogue differentiation
- genre promise
- continuity
- pacing
- redundancy
- ending/payoff
- format compliance
- pitch/package completeness

A future market-research connector can add current submission requirements
without contaminating the creative engine.

## Recommended production architecture

```text
                 PROJECT MEMORY
                      |
             +--------+--------+
             |                 |
        STORY STATE        CONTINUITY LEDGER
             |                 |
             +--------+--------+
                      |
                PROMPT COMPILER
                      |
        +-------------+-------------+
        |             |             |
     ARCHITECT     CHARACTER     GENRE
        |             |             |
        +-------------+-------------+
                      |
                    SCENE
                      |
              +-------+-------+
              |               |
           DIALOGUE        COMEDY/TV
              |               |
              +-------+-------+
                      |
                  CONTINUITY
                      |
                    EDITOR
                      |
                  PACKAGER
                      |
      +---------------+----------------+
      |               |                |
     NOVEL        SCREENPLAY        YOUTUBE/TV
```

## Important boundary

Muse is designed to create original work. It should not be instructed to clone a
living writer's distinctive voice. Named authors can be used as high-level
reference points for discussing craft history, but generation should use
attributes, genre conventions, and original synthesis.

## Status

This package is an upgraded orchestration foundation, not a claim that a model
automatically produces publication-ready manuscripts without human editorial
review. The autonomous loop can generate drafts and revision passes, but
quality still depends on the model backend, project brief, continuity context,
and editorial gates.
