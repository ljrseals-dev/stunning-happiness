from pathlib import Path
from muse_agent.core import StoryState, extract_signals, scene_diagnostics


def test_state_roundtrip(tmp_path):
    s = StoryState(title="X", premise="A secret door", genre="horror")
    s.decisions.append("door opens")
    s.save(tmp_path)
    r = StoryState.load(tmp_path)
    assert r.title == "X"
    assert r.decisions == ["door opens"]


def test_signals():
    x = extract_signals("She feared the door and loved him anyway.")
    assert "fear" in x["emotion"]
    assert "door" in x["image"]


def test_scene_gate():
    d = scene_diagnostics({"text": "short"})
    assert any("SCENE_TOO_SHORT" in x for x in d)
