# Muse 2.0 Architecture

## Agent responsibilities

### Architect
Premise, stakes, structure, reversals, ending.

### Character
Want/need, wound, contradiction, relationship dynamics, transformation.

### Scene
Objective, obstacle, tactics, escalation, turn, aftermath.

### Dialogue
Voice differentiation, subtext, status, rhythm, silence.

### Genre
Genre promise, conventions, escalation, novelty, reader expectations.

### Continuity
Timeline, geography, clues, objects, relationships, facts, unresolved threads.

### Editor
Developmental and line-level diagnostics.

### Packager
Logline, synopsis, pitch, episode descriptions, query components, metadata.

### Comedy
A specialist pass for setup, expectation, escalation, reversal, specificity,
status, and button.

### TV
Acts, teaser, act-outs, episode engine, ensemble dynamics, broadcast constraints.

## Why this is not "just one giant prompt"

A single prompt tends to blend incompatible objectives. Muse separates the
objectives and preserves a state ledger between passes. This makes the system
auditable and allows a stronger model to be swapped in later.

## Neural model layer

The model adapter is deliberately tiny:

```python
class ModelAdapter:
    def generate(self, prompt: str) -> str:
        ...
```

This permits:

- hosted LLMs
- local transformer models
- inference servers
- custom neural networks
- deterministic test doubles

The application owns the workflow. The neural model supplies generation.

## Autonomous loop

1. Load project state.
2. Compile specialist prompt.
3. Generate.
4. Store result.
5. Feed result/context into next specialist.
6. Run continuity and genre gates.
7. Revise.
8. Package.
9. Save every pass.

For unattended operation, add an external scheduler/queue and a persistent
model adapter. The core deliberately does not hide network credentials or
invent background execution.
