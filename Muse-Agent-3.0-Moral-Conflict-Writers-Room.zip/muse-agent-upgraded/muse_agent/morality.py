"""Moral-conflict and ethical-narrative engine for MUSE.

The engine is designed for fiction, not for declaring a universal moral winner.
It combines established moral-reasoning frameworks with a source-grounded
Christian narrative lens and forces characters to confront consequences.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List


@dataclass(frozen=True)
class EthicalFramework:
    name: str
    question: str
    strengths: str
    blind_spot: str


FRAMEWORKS = {
    "rest_four_component": EthicalFramework(
        "Rest Four-Component Model",
        "Can the character notice the moral stakes, judge the options, prioritize the moral value, and actually carry out the choice?",
        "Separates moral awareness, judgment, motivation, and action.",
        "A character can reason correctly and still fail under pressure, fear, habit, or social cost.",
    ),
    "duty": EthicalFramework(
        "Duty / Deontological Reasoning",
        "What obligation or rule must not be violated, even when violating it would be convenient?",
        "Creates hard boundaries and principled conflict.",
        "Rigid duties can collide when two obligations cannot both be satisfied.",
    ),
    "consequence": EthicalFramework(
        "Consequential Reasoning",
        "Which available action produces the least destructive or most beneficial foreseeable consequences?",
        "Makes second- and third-order consequences narratively visible.",
        "Predicted consequences are uncertain and can rationalize harmful means.",
    ),
    "virtue": EthicalFramework(
        "Virtue Ethics",
        "What kind of person is this choice making the character become?",
        "Excellent for character arcs and transformation.",
        "Virtues can conflict, and characters may disagree about what counts as courage, justice, or loyalty.",
    ),
    "care": EthicalFramework(
        "Care Ethics",
        "Who is vulnerable here, what relationships are at stake, and what response sustains human connection without enabling harm?",
        "Adds relational and contextual intelligence.",
        "Care for one person can impose costs on others or perpetuate unhealthy loyalty.",
    ),
    "justice": EthicalFramework(
        "Justice / Fairness",
        "Who bears the cost, who receives the benefit, and what would a fair process require?",
        "Useful for institutional, family, legal, and social conflict.",
        "Equal treatment and equitable treatment are not always the same.",
    ),
    "christian_jesus": EthicalFramework(
        "Jesus-Centered Christian Narrative Lens",
        "What response most faithfully reflects Jesus' teachings and example: love of God and neighbor, mercy, truth, forgiveness, humility, service, care for the vulnerable, reconciliation, and costly love?",
        "Provides a coherent spiritual/moral lens for stories in which faith is genuinely consequential.",
        "The framework should not erase consequences, justice, boundaries, or character agency; characters may fail, misunderstand, repent, resist, or disagree.",
    ),
}


@dataclass
class MoralDilemma:
    situation: str
    protagonist_value: str
    opposing_values: List[str]
    options: List[Dict[str, Any]] = field(default_factory=list)
    stakeholders: List[str] = field(default_factory=list)
    hidden_costs: List[str] = field(default_factory=list)
    temptation: str = ""
    truth_test: str = ""
    transformation_question: str = ""
    framework_notes: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def evaluate_dilemma(dilemma: MoralDilemma, frameworks: List[str] | None = None) -> Dict[str, Any]:
    names = frameworks or list(FRAMEWORKS)
    analysis: Dict[str, Any] = {"dilemma": dilemma.to_dict(), "frameworks": {}}
    for key in names:
        if key not in FRAMEWORKS:
            continue
        f = FRAMEWORKS[key]
        analysis["frameworks"][key] = {
            "name": f.name,
            "question": f.question,
            "strengths": f.strengths,
            "blind_spot": f.blind_spot,
        }
    return analysis


def conflict_prompt(dilemma: MoralDilemma, framework_keys: List[str] | None = None) -> str:
    analysis = evaluate_dilemma(dilemma, framework_keys)
    framework_text = "\n".join(
        f"- {k}: {v['question']}\n  Strength: {v['strengths']}\n  Blind spot: {v['blind_spot']}"
        for k, v in analysis["frameworks"].items()
    )
    return f"""MUSE MORAL CONFLICT LAB

Do not write a lecture. Dramatize the dilemma through desire, pressure, action, consequence, and character revelation.

SITUATION
{dilemma.situation}

PROTAGONIST'S CENTRAL VALUE
{dilemma.protagonist_value}

COMPETING VALUES
{', '.join(dilemma.opposing_values)}

STAKEHOLDERS
{', '.join(dilemma.stakeholders) or '[identify them]'}

TEMPTATION
{dilemma.temptation or '[identify the easiest self-justification]'}

TRUTH TEST
{dilemma.truth_test or '[identify what the protagonist does not want to admit]'}

TRANSFORMATION QUESTION
{dilemma.transformation_question or '[what kind of person will this choice make them?]'}

ETHICAL LENSES
{framework_text}

OPTIONS
{dilemma.options or '[generate at least three materially different choices]'}

REQUIRED NARRATIVE BEHAVIOR
1. Make every option costly; avoid fake dilemmas.
2. Give the protagonist a psychologically credible reason to choose each option.
3. Show who benefits and who pays for each choice.
4. Separate intention from consequence.
5. Permit moral injury, regret, repentance, forgiveness, boundary-setting, or reconciliation where causally earned.
6. Do not automatically reward the morally correct choice with a happy ending.
7. Do not make the Christian lens a slogan. If used, dramatize it through behavior, sacrifice, mercy, truth, service, forgiveness, or refusal of vengeance.
8. If the protagonist invokes Jesus, distinguish what Jesus' teaching says from what the character merely wants it to say.
9. Preserve cultural, historical, and generational specificity.
10. End with a choice that changes the story rather than an abstract moral conclusion.
"""
