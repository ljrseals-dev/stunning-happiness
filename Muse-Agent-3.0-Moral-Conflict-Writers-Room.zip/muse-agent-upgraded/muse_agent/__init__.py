"""Muse Autonomous Writers' Room."""

__version__ = "2.0.0"

from .morality import FRAMEWORKS, MoralDilemma, evaluate_dilemma, conflict_prompt
