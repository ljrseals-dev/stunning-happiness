from muse_agent.morality import FRAMEWORKS, MoralDilemma, evaluate_dilemma, conflict_prompt


def test_framework_catalog():
    assert "rest_four_component" in FRAMEWORKS
    assert "christian_jesus" in FRAMEWORKS
    assert len(FRAMEWORKS) >= 6


def test_dilemma_analysis():
    d = MoralDilemma(
        situation="A daughter learns her brother committed a crime.",
        protagonist_value="family loyalty",
        opposing_values=["truth", "justice", "mercy"],
        stakeholders=["daughter", "brother", "victim"],
        temptation="Protect the family name.",
    )
    x = evaluate_dilemma(d)
    assert "rest_four_component" in x["frameworks"]
    assert "christian_jesus" in x["frameworks"]


def test_conflict_prompt_requires_cost_and_action():
    d = MoralDilemma("A secret can save one person and destroy another.", "loyalty", ["truth", "mercy"])
    p = conflict_prompt(d, ["rest_four_component", "christian_jesus"])
    assert "Make every option costly" in p
    assert "End with a choice" in p
