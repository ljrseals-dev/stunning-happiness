# MUSE Moral Conflict Engine

## Purpose

MUSE treats ethics as a **dramatic engine**, not as an after-the-fact moral paragraph. A strong dilemma puts a character between values that matter, makes every available action costly, and lets the decision create consequences.

## Research-informed foundation

The implementation uses Rest's Four-Component model as a behavioral decomposition: moral sensitivity, moral judgment, moral motivation, and moral character/action. This is useful for fiction because a character may recognize the right issue, reason well, value the right thing, and still fail to act—or act courageously while reasoning imperfectly.

It also supports duty/deontological, consequence-oriented, virtue, care, and justice lenses. These are **analytic lenses**, not an algorithm for discovering one universally correct answer.

## Christian / Jesus-centered narrative lens

When explicitly requested, the system uses a Christian narrative framework centered on teachings attributed to Jesus in the Gospels. Core themes include love of God and neighbor, mercy, truthfulness, forgiveness, humility, service, care for vulnerable people, reconciliation, and love even toward enemies. Matthew 5–7 and Matthew 22:36–40 are useful anchor passages.

The engine must not turn these teachings into automatic plot rewards. A character can understand the teaching and fail. A character can forgive while maintaining a boundary. Mercy can have a cost. Truth can fracture a family before reconciliation becomes possible. The story should show the moral struggle rather than announce the answer.

## Conflict matrix

For every major moral choice, MUSE should record:

1. **Facts** — what is actually known.
2. **Perception** — what the character believes.
3. **Duty** — what the character thinks they owe.
4. **Desire** — what they want.
5. **Fear** — what they cannot bear to lose.
6. **Temptation** — the attractive self-justification.
7. **Victims/stakeholders** — who bears the consequences.
8. **Options** — at least three materially different choices.
9. **Second-order effects** — what each choice causes next.
10. **Identity cost** — what kind of person each choice makes the character become.
11. **Repair** — confession, restitution, forgiveness, punishment, reconciliation, or boundary-setting where appropriate.

## Generational application

For African and African American family narratives, moral conflict should be attached to historical and generational context without assuming one universal Black experience. The same dilemma can produce different choices in a 1940s rural Southern grandmother, a 1970s Detroit father, and a contemporary Memphis daughter because their institutions, economic conditions, language, faith, technology, and memories differ.

## Quality gate

A moral subplot is weak if:

- one side is obviously stupid or evil;
- the protagonist has no meaningful cost;
- the dilemma disappears after a speech;
- Christian language substitutes for character action;
- forgiveness erases accountability;
- justice is confused with revenge;
- trauma is used as an excuse for every choice;
- the narrator tells the reader whom to admire instead of dramatizing consequences.

A strong moral subplot leaves the reader thinking: **I understand why they chose it—and I am not sure I would have chosen differently.**
