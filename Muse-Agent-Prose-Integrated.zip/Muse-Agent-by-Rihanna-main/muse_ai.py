#!/usr/bin/env python3
"""
muse_ai.py
==========

OpenAI-compatible chat-completions client for Muse Prose Writer.

Standard library only (urllib). No pip packages.

Configuration via environment variables:

  MUSE_AI_API_KEY     Required for live calls.
  MUSE_AI_BASE_URL    Default: https://api.x.ai/v1
  MUSE_AI_MODEL       Default: grok-2-latest
  MUSE_AI_TIMEOUT     Seconds, default 120
  MUSE_AI_MAX_TOKENS  Default 2048
  MUSE_AI_TEMPERATURE Default 0.7

Compatible with any OpenAI-style /chat/completions endpoint (xAI, OpenAI,
local servers, etc.).

Usage with muse_prose:

  from muse_ai import OpenAICompatibleBackend, AiConfig
  from muse_prose import ProseWriter

  writer = ProseWriter(backend=OpenAICompatibleBackend())
  written = writer.write(brief)
"""

from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Optional

# Soft dependency on muse_prose for the backend protocol
try:
    from muse_prose import AssembledPrompt, PromptAssembler, SceneBrief
except ImportError:  # pragma: no cover
    AssembledPrompt = Any  # type: ignore
    PromptAssembler = None  # type: ignore
    SceneBrief = Any  # type: ignore


@dataclass
class AiConfig:
    api_key: str = ""
    base_url: str = "https://api.x.ai/v1"
    model: str = "grok-2-latest"
    timeout: float = 120.0
    max_tokens: int = 2048
    temperature: float = 0.7

    @classmethod
    def from_env(cls) -> "AiConfig":
        return cls(
            api_key=os.environ.get("MUSE_AI_API_KEY", "").strip(),
            base_url=os.environ.get("MUSE_AI_BASE_URL", "https://api.x.ai/v1").rstrip("/"),
            model=os.environ.get("MUSE_AI_MODEL", "grok-2-latest"),
            timeout=float(os.environ.get("MUSE_AI_TIMEOUT", "120")),
            max_tokens=int(os.environ.get("MUSE_AI_MAX_TOKENS", "2048")),
            temperature=float(os.environ.get("MUSE_AI_TEMPERATURE", "0.7")),
        )

    def is_configured(self) -> bool:
        return bool(self.api_key)


class ChatCompletionsClient:
    """Minimal OpenAI-compatible chat completions HTTP client."""

    def __init__(self, config: Optional[AiConfig] = None) -> None:
        self.config = config or AiConfig.from_env()

    def complete(self, messages: list[dict[str, str]]) -> str:
        if not self.config.is_configured():
            raise RuntimeError(
                "MUSE_AI_API_KEY is not set. Export an API key, or use the "
                "deterministic prose backend (omit --ai)."
            )
        url = f"{self.config.base_url}/chat/completions"
        body = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.config.api_key}",
                "User-Agent": "muse-agent/prose",
            },
        )
        ctx = ssl.create_default_context()
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout, context=ctx) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"AI API HTTP {e.code}: {detail}") from e
        except urllib.error.URLError as e:
            raise RuntimeError(f"AI API network error: {e}") from e

        try:
            return payload["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as e:
            raise RuntimeError(f"Unexpected AI API response shape: {payload!r}") from e


class OpenAICompatibleBackend:
    """
    ProseBackend that sends PromptAssembler output to a chat-completions API.
    Implements the same render(brief) -> str contract as DeterministicBackend.
    """

    def __init__(
        self,
        config: Optional[AiConfig] = None,
        assembler: Optional[Any] = None,
        client: Optional[ChatCompletionsClient] = None,
    ) -> None:
        self.config = config or AiConfig.from_env()
        if assembler is not None:
            self.assembler = assembler
        elif PromptAssembler is not None:
            self.assembler = PromptAssembler()
        else:
            self.assembler = None
        self.client = client or ChatCompletionsClient(self.config)

    def render(self, brief: "SceneBrief") -> str:
        if self.assembler is None:
            raise RuntimeError("muse_prose.PromptAssembler is not available")
        assembled: AssembledPrompt = self.assembler.assemble(brief)
        messages = assembled.as_messages()
        return self.client.complete(messages)


def status_report() -> str:
    cfg = AiConfig.from_env()
    lines = [
        "# Muse AI configuration",
        "",
        f"- base_url: {cfg.base_url}",
        f"- model: {cfg.model}",
        f"- timeout: {cfg.timeout}s",
        f"- max_tokens: {cfg.max_tokens}",
        f"- temperature: {cfg.temperature}",
        f"- api_key: {'set' if cfg.is_configured() else 'NOT SET'}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print(status_report())
